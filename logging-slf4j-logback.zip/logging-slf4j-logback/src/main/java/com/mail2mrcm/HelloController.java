package com.mail2mrcm;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.util.Arrays;
import java.util.List;

@RestController
public class HelloController {

    private static final Logger logger = LoggerFactory.getLogger(HelloController.class);

    @GetMapping("/{name}")
    public String hello(@PathVariable String name) {
        logger.debug("Debug Details: {}", name);
	logger.info("Debug Details: {}", name);
        return "Hello " + name;
    }

   @GetMapping("hello/{name}")
    public String wellcome(@PathVariable String name) {       
	logger.error("Error Details: {}", name);
        return "Hello " + name;
    }

}